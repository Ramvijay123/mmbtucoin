<!DOCTYPE HTML>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="keywords" content="">
<meta name="description" content="">
<title>MMBTU Coin</title>
<!--Bootstrap -->
<link rel="stylesheet" href="<?php echo base_url();?>assests/css/bootstrap.min.css" type="text/css">
<!--Custome Style -->
<link rel="stylesheet" href="<?php echo base_url();?>assests/css/style.css" type="text/css">
<!--FontAwesome Font Style -->
<link href="<?php echo base_url();?>assests/css/font-awesome.min.css" rel="stylesheet">
<!-- Fav and touch icons -->
<link rel="shortcut icon" href="<?php echo base_url();?>assests/images/favicon-icon/favicon.png">
<!-- Google-Font-->
<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700" rel="stylesheet"> 
<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->  
</head>
<body>
<div class="form_wrap">
	<div class="form_container">
    	<div class="form_header">
        	<a href="index.html"><img src="<?php echo base_url();?>assests/images/logo.png" alt="image"></a>
        </div>
        <div class="form_inner">
        	<h1>Login</h1>
            <form>
                <div class="form-group">
                    <input type="email" class="form-control" placeholder="Email Address">
                </div>
                <div class="form-group">
                    <input type="password" class="form-control" placeholder="Password">
                </div>
                <div class="form-group btn_group">
                	<input class="btn" value="Sing In" type="submit">
                </div>
            </form>
            <p><a href="register">Sign up for an account</a> | <a href="forgetpassword">Forgot Your Password?</a></p>
            <p><a href="#">Didn't receive confirmation email? </a></p>
       </div>     
    </div>
</div>

<!-- Scripts --> 
<script src="<?php echo base_url();?>assests/js/jquery.min.js"></script>
<script src="<?php echo base_url();?>assests/js/bootstrap.min.js"></script> 
<script src="<?php echo base_url();?>assests/js/particles.min.js"></script>
<script src="<?php echo base_url();?>assests/js/app.js"></script>
</body>
</html>